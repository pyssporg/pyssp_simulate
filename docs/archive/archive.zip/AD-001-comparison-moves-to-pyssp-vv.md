---
id: AD-001
title: Comparison moves to pyssp_vv
summary: Comparison and verdicts leave pyssp_simulate; measurement and judgment live in pyssp_vv, and permutations may call pyssp_vv.measure locally
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - src/pyssp_simulate/permutations.py
  - src/pyssp_simulate/cli.py
  - src/pyssp_simulate/__init__.py
  - pyproject.toml
  - tests/test_cli.py
  - tests/test_permutations.py
supersedes: []
superseded_by: []
related: []
---

# AD-001: Comparison moves to pyssp_vv

## Context

- `compare.py` shipped cross-engine and reference-CSV comparison: `PairReport.passed`, a `compare` CLI subcommand, and a `compare` block in permutation config.
- Comparison gave the package a second reason to change, numerical practice, and put acceptance logic inside a simulation substrate.
- `ComparisonWindow`, `compare_to_reference`, and `SimulationResult.from_reference_csv` arrived in 0.1.1 for one consumer's analysis needs.
- No project outside `pyssp_simulate` imported `compare`, `compare_to_reference`, `PairReport`, or `ComparisonWindow`, and no script invoked `pyssp-simulate compare`.
- Extracting the module cost one internal import.

## Decision

- Comparison left this package: `compare.py`, the `compare` CLI subcommand, and the comparison exports are removed; version became 0.2.0.
- Measurement and judgment live in `pyssp_vv`: `measure` for trajectories, alignment, and metrics; `judge` for criteria and verdicts.
- A `compare` key in a permutation config is rejected, so an old config fails loudly instead of silently losing its tolerance.
- `permutations` may import `pyssp_vv.measure` locally for sweep reporting; that surface is not re-exported and `judge` is never imported.
- `PermutationRun.report` became `measurements`, `PermutationRun.passed` was removed, and `run-all` reports metrics without a verdict.

## Rationale

- One reason to change per package: engines and SSP runtime here, numerical judgment there.
- Acceptance logic is a decision, and a simulation substrate must never return one.
- Extraction was cheap: one internal module and no external consumer.

## Alternatives Considered

- Keep `compare` and add judgment later: rejected, it leaves two implementations and two reasons to change.
- Keep `compare` but drop `passed()`: rejected, reference-CSV and window handling still belong to analysis.
- Depend on `pyssp_vv` at module scope: rejected, it makes the substrate uninstallable without the measurement extra.

## Consequences

- Positive: the public API holds no acceptance decision, and measurement is an optional extra (`pyssp-vv[measure]`).
- Positive: base installs import and simulate without the extra; a multi-backend sweep without it raises an actionable `ImportError`.
- Negative: a consumer that scripted `pyssp-simulate compare` must move to `pyssp_vv`; none was found in the pyssp organization.

## Verification

- `tests/test_cli.py` asserts the `compare` subcommand is gone.
- `tests/test_permutations.py` asserts the `compare` config key is rejected.
- `pytest` passes; `pyssp_vv.judge` is never imported.

## Review Trigger

- A consumer needs trajectory comparison from `pyssp_simulate`, or `pyssp_vv.measure` changes its interface.
